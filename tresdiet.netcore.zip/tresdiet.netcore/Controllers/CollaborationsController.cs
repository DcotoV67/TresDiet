using Microsoft.AspNetCore.Mvc;

public class CollaborationsController : Controller
{
    public IActionResult Index(string name)
    {
        return View();
    }

     public IActionResult Search(string name)
    {
        return View();
    }
      public IActionResult Invoices(string name)
    {
        return View();
    }
        public IActionResult Create(string name)
    {
        return View();
    }
     public IActionResult Bills(string name)
    {
        return View();
    }

}