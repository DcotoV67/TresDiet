using Microsoft.AspNetCore.Mvc;

public class LoginController : Controller
{
    public IActionResult Index(string name)
    {
        return View();
    }
     public IActionResult LogIn(string name)
    {
        return View();
    }
     public IActionResult LogOut(string name)
    {
        return View();
    }
}