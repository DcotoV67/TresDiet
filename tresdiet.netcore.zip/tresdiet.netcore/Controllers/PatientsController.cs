using Microsoft.AspNetCore.Mvc;

public class PatientsController : Controller
{
    public IActionResult Index(string name)
    {
        return View();
    }

    public IActionResult Create(string name)
    {
        return View();
    }
     public IActionResult Search(string name)
    {
        return View();
    }
    
     public IActionResult Change(string name)
    {
        return View();
    }
    
}