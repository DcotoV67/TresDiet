using Microsoft.AspNetCore.Mvc;

public class ProfileController : Controller
{
    public IActionResult Index(string name)
    {
        return View();
    }
 
}