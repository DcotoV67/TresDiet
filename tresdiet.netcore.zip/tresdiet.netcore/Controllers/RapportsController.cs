using Microsoft.AspNetCore.Mvc;

public class RapportsController : Controller
{
    public IActionResult Index(string name)
    {
        return View();
    }
         public IActionResult Create(string name)
    {
        return View();
    }
    public IActionResult Search(string name)
    {
        return View();
    }
    
     public IActionResult Calendar(string name)
    {
        return View();
    }
     public IActionResult Observations(string name)
    {
        return View();
    }


}