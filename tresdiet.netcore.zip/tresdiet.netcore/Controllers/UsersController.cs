using Microsoft.AspNetCore.Mvc;

public class UsersController : Controller
{
    public IActionResult Index(string name)
    {
        return View();
    }
    
     public IActionResult Search(string name)
    {
        return View();
    }
    
     public IActionResult Update(string name)
    {
        return View();
    }
 
}